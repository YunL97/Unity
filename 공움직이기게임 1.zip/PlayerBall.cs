﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerBall : MonoBehaviour
{
    void Awake()
    {

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        
    }
}
