﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemCan : MonoBehaviour
{

    public float rotateSpeed;
    // Update is called once per frame
    void Update()
    {
        transform.Rotate(Vector3.up * rotateSpeed * Time.deltaTime,Space.World); //Global로
    }
    void OntriggerEnter(Collider other)
    {
        if(other.name == "Player")
        {
            //gameObject:자기자신
            PlayerBall player =  other.GetComponent<PlayerBall>();
            player.itemCount++;
            gameObject.SetActive(false);
        }
    }
}
