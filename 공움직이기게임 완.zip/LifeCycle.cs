﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LifeCycle : MonoBehaviour
{

    void Start()
    {
        //vector3 :3차원 vector2 :2차원
        //Translate:벡터값을 현재 위치에 더하는 함수
        Vector3 vec = new Vector3(5, 0, 0); //벡터 값
        transform.Translate(vec);

       // int number = 4; //스칼라 : 순수한 값
        //35:22
    }
    /*
     void Awake() //오브젝트 생성할 때 최초로 딱한번만 실행되는 함수
    {
        Debug.Log("플레이어 데이터가 준비되었습니다.");
    }

    void OnEnable() //초기화 영역과 물리연산 사이에 위치함,onenable는 게임 오브젝트가 활성화 되었을때
    {
        Debug.Log("플레이어가 로그인했습니다.");
    }

    void Start() //업데이트 시작직전 최초로 딱 한번만 실행되는 함수
    {
        Debug.Log("사냥 장비를 챙겼습니다");
    }

    

    void FixedUpdate() //물리연산 업데이트 함수, 고정된 실행주기로 CPU를 많이 사용
    {
        Debug.Log("이동");
    }
    */

    /*
void Update() //게임 로직 업데이트 함수, 60 프레임, 사용되는 컴퓨터 환경에 따라 실행주기 떨어질 수 있음
{
    if (Input.anyKeyDown)
        Debug.Log("플레이어가 아무 키를 눌렀습니다");

    //if(Input.anyKey)
    //   Debug.Log("플레이어가 아무 키를 누르고 있습니다");

    if (Input.GetKeyDown(KeyCode.Return))
        Debug.Log("아이템을 구입하였습니다.");

    if (Input.GetKey(KeyCode.LeftArrow))
        Debug.Log("왼쪽으로 이동");

    if (Input.GetKey(KeyCode.RightArrow))
        Debug.Log("오른쪽으로 이동");


    if (Input.GetMouseButtonDown(0))
        Debug.Log("미사일 발사");

    if (Input.GetMouseButton(0))
        Debug.Log("미사일 발사");

    if (Input.GetMouseButtonUp(0))
        Debug.Log("슈퍼 미사일 발사");


    //횡이동
    if (Input.GetButton("Horizontal"))
        Debug.Log("횡 이동중"
            + Input.GetAxisRaw("Horizontal"));
    //Input.GetAxis("Horizontal");

    //종이동
    if (Input.GetButton("Vertical"))
        Debug.Log("종 이동중"
            + Input.GetAxisRaw("Vertical"));
}

*/







    /*
    void LateUpdate() //모든 업데이트 함수 실행 후 마지막으로 실행되는 함수. ex)캐릭터를 따라가는 카메라처리
    {
        Debug.Log("경험치 획득.");
    }

    void OnDisable() //모든 업데이트가 끝난 후, OnDisable: 게임 오브젝트가 비활성화 되었을때 호출
    {
        Debug.Log("플레이어가 로그아웃했습니다");
    }

    void OnDestroy() //게임오브젝트가 삭제될때
    {
        Debug.Log("플레이어 데이터를 해제하였습니다");
    }
    */
}
