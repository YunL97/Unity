﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : Actor
{
   public string move()
    {
        return "플레이어는 움직입니다.";
    }
}
